# Update Naukri Profile (SAFE Template)

This repository contains a **safe GitHub Actions workflow** and a **template agent.js** file.
**It does NOT contain any code that automates logging in to Naukri or performing actions on the site.**

Contents:
- `.github/workflows/update-naukri-profile.yml` — workflow that runs `node agent.js` on schedule
- `agent.js` — SAFE template (placeholder). Replace with your own, compliant implementation.
- `package.json` — minimal Node.js file
- `README.md` — this file

How to use on mobile (no copy/paste):
1. Download the ZIP and upload it to a **new GitHub repository** (use "Add file → Upload files").
2. Go to **Settings → Secrets and variables → Actions** and add:
   - `NAUKRI_USER` (your Naukri username/email)
   - `NAUKRI_PASS` (your Naukri password)
3. If you want this repository to actually perform updates, implement your own safe logic in `agent.js`.
   - **Do not** add code here that logs in automatically to a website unless you are sure it's allowed by that site's terms.
   - Prefer calling an official API or running the automation on a machine you control.
4. Go to **Actions** tab → choose "Update Naukri Profile" → click "Run workflow".

Need help adding a compliant approach (for example: calling your own server or using an official API)? Reply and I’ll suggest safe options.

---
Generated for: Aditya
